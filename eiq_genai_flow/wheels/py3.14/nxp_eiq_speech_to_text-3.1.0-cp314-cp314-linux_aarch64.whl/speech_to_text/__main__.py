# Copyright 2024-2026 NXP
# NXP Confidential and Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

import logging
import argparse
import numpy as np
import alsaaudio as aa
from vad.vad import VAD
from pathlib import Path
from collections import deque
from speech_to_text.speech_to_text import SpeechToText
from speech_to_text.utils.utils import consume_buffer, split, load_audio
from speech_to_text.models.model_config import ModelConfig
from shared_utils.utils import parent_dir, get_leaf_classes, setup_logging, get_default_playback_device


logger = logging.getLogger(__name__)


def mic_to_text(stt: SpeechToText, vad: VAD, timeout_s=20):
    assert stt.sample_rate == vad.sample_rate

    num_channels = 1
    device = get_default_playback_device()

    pcm = aa.PCM(
        type=aa.PCM_CAPTURE,
        rate=stt.sample_rate,
        channels=num_channels,
        device=device,
        format=aa.PCM_FORMAT_FLOAT_LE,
        periodsize=vad.required_samples
    )

    speech_to_process = deque()

    def process_chunk(chunk, is_speech):
        """Yield STT results, handling speech buffering."""
        if is_speech and chunk is not None:
            speech_to_process.extend(chunk)
            if len(speech_to_process) >= stt.current_chunk_length:
                yield from stt(consume_buffer(speech_to_process, stt.current_chunk_length))
        elif speech_to_process:  # Speech just ended
            yield from stt(consume_buffer(speech_to_process, len(speech_to_process)), ending=True)

    logger.info("Recording from microphone...\n")

    for _ in range(int(timeout_s * stt.sample_rate / vad.required_samples)):
        length, data = pcm.read()
        if length <= 0:
            continue

        chunk = np.frombuffer(data, dtype=np.float32).copy()
        is_speech, chunk, _ = vad(chunk)

        yield from process_chunk(chunk, is_speech)

    # Flush remaining audio
    vad.flush()

    # Process any remaining speech
    if speech_to_process:
        yield from stt(consume_buffer(speech_to_process, len(speech_to_process)), ending=True)

    logger.info('Timeout!')


def file_to_text(stt: SpeechToText, vad: VAD, audio_file: str | Path):
    audio_input = load_audio(audio_file, sample_rate=stt.sample_rate)
    audio_input = audio_input[stt.audio_channel_index]

    is_speech, audio_input, _ = vad(audio_input, streaming=False)

    # no speech detected
    if not is_speech:
        logger.warning(f'Audio {audio_file} is empty!')
        return ''

    if stt.model_type == 'whisper':
        input_chunks = stt.audio_processor.split(audio_input)
    else:
        input_chunks = split(audio_input, stt.current_chunk_length)

    text = ''
    for chunk_idx, chunk in enumerate(input_chunks):
        for text in stt(chunk, ending=(chunk_idx == len(input_chunks) - 1)):
            pass

    return text


def file_to_text_streaming(stt: SpeechToText, vad: VAD, audio_file: str | Path):
    audio_input = load_audio(audio_file, sample_rate=stt.sample_rate)

    # If benchmarking multiple files with same vad instance, you must reset vad state for each function call
    vad.init_streaming_state()

    audio_input = audio_input[stt.audio_channel_index]

    processed_chunks = []
    speech_buffer = []

    for start_idx in range(0, audio_input.shape[-1], vad.required_samples):
        end_idx = min(start_idx + vad.required_samples, audio_input.shape[-1])
        chunk = audio_input[start_idx:end_idx]

        if chunk.shape[-1] < vad.required_samples:
            logger.debug(
                f"Incomplete chunk ({chunk.shape[-1]} samples), "
                f"VAD needs {vad.required_samples}."
            )
            break

        is_speech, chunk, _ = vad(chunk)
        if is_speech:
            speech_buffer.append(chunk)
        elif speech_buffer:  # Speech just ended
            processed_chunks.append(np.concatenate(speech_buffer, axis=-1))
            speech_buffer = []

    # Handle case where speech continues until end of file
    if speech_buffer:
        processed_chunks.append(np.concatenate(speech_buffer, axis=-1))

    vad.flush()

    if not processed_chunks:
        logger.warning(f'Audio {audio_file} is empty!')
        return ''

    audio_input = np.concatenate(processed_chunks, axis=-1)

    if stt.model_type == 'whisper':
        input_chunks = stt.audio_processor.split(audio_input)
    else:
        input_chunks = split(audio_input, stt.current_chunk_length)

    text = ''
    for chunk_idx, chunk in enumerate(input_chunks):
        for text in stt(chunk, ending=(chunk_idx == len(input_chunks) - 1)):
            pass

    return text


def parse_args():
    parser = argparse.ArgumentParser(description="Audio processing options")
    supported_models = [cls.name for cls in get_leaf_classes(ModelConfig)]
    logging_levels = list(logging._levelToName.values())

    parser.add_argument(
        '-m', '--model',
        type=str.lower,
        choices=supported_models,
        default='whisper-small.en',
        help="Speech-To-Text model to use."
    )
    parser.add_argument(
        '-f', '--file',
        metavar='path/to/the/input_file',
        help="Optional: path to the input audio file. "
             "If omitted, the microphone will be used."
    )
    parser.add_argument(
        '-v', '--verbose',
        type=str.upper,
        choices=logging_levels,
        default='INFO',
        help="Specify the verbose mode."
    )
    args = parser.parse_args()

    # Determine source automatically
    if args.file:
        args.source = 'file'
    else:
        args.source = 'mic'

    return args


def main():
    args = parse_args()
    setup_logging(level=logging._nameToLevel[args.verbose], root_path=parent_dir(__file__, level=3))

    stt = SpeechToText(args.model, language='English', task='transcribe')
    vad = VAD()

    match args.source:
        case 'mic':
            for _ in mic_to_text(stt, vad, timeout_s=20):
                pass

        case 'file':
            logger.info(f'Using file: {args.file}\n')
            file_to_text_streaming(stt, vad, audio_file=args.file)


if __name__ == '__main__':
    main()
