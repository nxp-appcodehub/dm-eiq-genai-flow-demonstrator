# Copyright 2026 NXP
# NXP Confidential and Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

import logging
import argparse
import numpy as np
import alsaaudio as aa
from pathlib import Path
from collections import deque
from shared_utils.utils import get_leaf_classes, parent_dir, setup_logging, get_default_playback_device
from vad.vad import VAD
from voice_id.utils import consume_buffer, load_audio, split
from voice_id.speaker import SpeakerEncoder, compare_speakers
from voice_id.models.model_config import ModelConfig
from typing import Optional


logger = logging.getLogger(__name__)


def mic_to_id(speaker_encoder: SpeakerEncoder, vad: Optional[VAD] = None, timeout_s=10):
    if vad is not None:
        assert speaker_encoder.model_config.sample_rate == vad.sample_rate

    sample_rate = speaker_encoder.model_config.sample_rate
    window_size_s = speaker_encoder.model_config.micro_required_samples / sample_rate
    speech_to_process = deque()

    # setup alsa:
    capture_device = get_default_playback_device()
    pcm = aa.PCM(
        type=aa.PCM_CAPTURE,
        rate=sample_rate,
        channels=1,
        device=capture_device,
        format=aa.PCM_FORMAT_FLOAT_LE,
        periodsize=speaker_encoder.model_config.micro_required_samples
    )

    logger.info("Recording from microphone...\n")

    total_frames = int(timeout_s / window_size_s)

    for frame_idx in range(total_frames):
        l, data = pcm.read()
        if l > 0:
            chunk = np.frombuffer(data, dtype=np.float32).copy()
            if vad is not None:
                is_speech, chunk, _ = vad(chunk)

                if is_speech:
                    speech_to_process.extend(chunk)
                elif speech_to_process:  # Speech just ended
                    chunk = consume_buffer(speech_to_process, len(speech_to_process))
                    chunk.reshape(1, -1)
                    return speaker_encoder(chunk)

            # NO VAD
            else:
                # No vad option, simply take the whole signal
                speech_to_process.extend(chunk)

        # enough sample in self.speech_to_process to send
        if len(speech_to_process) > speaker_encoder.model_config.audio_chunk_length:
            logger.debug(f"Sending audio of length {len(speech_to_process)}")
            chunk = consume_buffer(speech_to_process, speaker_encoder.model_config.audio_chunk_length)
            chunk.reshape(1, -1)
            return speaker_encoder(chunk)

    logger.info('Timeout!')
    return None


def file_to_id(speaker_encoder: SpeakerEncoder, audio_file: str | Path, vad: Optional[VAD] = None):
    input_chunks = load_audio(audio_file, speaker_encoder.model_config.sample_rate)[0]

    if vad is not None:
        is_speech, input_chunks, _ = vad(input_chunks, streaming=False)

        # no speech detected
        if not is_speech:
            logger.info(f'Audio {audio_file} is empty!')
            return None

    input_chunks = split(input_chunks, speaker_encoder.model_config.audio_chunk_length)
    for _, chunk in enumerate(input_chunks):
        if len(chunk) >= speaker_encoder.model_config.model_required_samples:
            # verify that enough samples to send to the model
            yield speaker_encoder(chunk)


def parse_args():

    parser = argparse.ArgumentParser(description="Voice Identification options.")

    supported_models = [cls.name for cls in get_leaf_classes(ModelConfig)]
    logging_levels = list(logging._levelToName.values())

    parser.add_argument(
        '-m', '--model',
        type=str.lower,
        choices=supported_models,
        default='resnet34',
        help="Voice Identification model to use."
    )
    parser.add_argument(
        '-v', '--verbose',
        type=str.upper,
        choices=logging_levels,
        default='INFO',
        help="Specify the verbose mode."
    )
    parser.add_argument(
        '-f', '--file',
        nargs="+",
        metavar='path/to/the/input_file',
        help="Optional: At least 2 path to input audio "
             "If there is less than 2 path, it will raise an error"
             "If omitted, the microphone will be used."
    )
    parser.add_argument(
        '--vad',
        action='store_true',
        default=False,
        help="Enable vad option. "
    )

    args = parser.parse_args()

    # Determine source automatically
    if args.file:
        # Verify that there is at leat 2 files audio to compare
        if len(args.file) < 2:
            raise ValueError("At least 2 path files are required for compare")

        args.source = 'file'

    else:
        args.source = 'mic'

    return args


def main():

    args = parse_args()
    setup_logging(level=logging._nameToLevel[args.verbose], root_path=parent_dir(__file__, level=3))

    speaker_encoder = SpeakerEncoder(name=args.model)
    speakers = []  # used as historical of speakers

    # If option --vad is passed and submodule up to date, vad is used
    vad_option = args.vad
    vad = None
    if vad_option:
        logger.info("Vad option enabled")
        vad = VAD()
    else :
        logger.info("Vad option not enabled")

    match args.source:

        case 'mic':
            last_known_speaker = None
            while (speaker := mic_to_id(speaker_encoder, vad)) is not None:
                if last_known_speaker is not None:
                    if speaker == last_known_speaker :
                        compare_speakers([speaker, last_known_speaker])
                        logger.info("Speaker recognized")
                    else :
                        logger.info("New speaker")
                else :
                    logger.info("New speaker")

                last_known_speaker = speaker

        case 'file':
            for arg in args.file:
                for spk in file_to_id(speaker_encoder, arg, vad):
                    if spk is not None:
                        speakers.append(spk)

            compare_speakers(speakers)


if __name__ == "__main__":
    main()
