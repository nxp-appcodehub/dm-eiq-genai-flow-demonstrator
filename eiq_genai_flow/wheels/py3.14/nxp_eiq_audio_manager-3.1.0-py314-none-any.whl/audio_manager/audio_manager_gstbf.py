# Copyright 2026 NXP
# NXP Confidential and Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

"""
GStreamer Audio Backend

Provides GStreamer-based audio capture and playback with support for
dynamic sample rate changes and hardware resampling.
"""

import logging
from typing import Optional
from audio_manager.audio_manager_base import CaptureConfig, PlaybackConfig
from audio_manager.audio_manager_gstreamer import AudioManagerGStreamer
import os

# Import gi and set versions BEFORE importing from gi.repository
import gi

gi.require_version("Gst", "1.0")
gi.require_version("GstApp", "1.0")

from gi.repository import Gst, GLib  # noqa: E402

# Initialize GStreamer framework
Gst.init(None)
logger = logging.getLogger(__name__)


class AudioManagerGStreamerBF(AudioManagerGStreamer):
    """GStreamer-based audio manager with Beamformer support."""

    def __init__(
        self,
        capture_config: Optional[CaptureConfig] = None,
        playback_config: Optional[PlaybackConfig] = None,
        start_glib_loop: bool = True,
        external_glib_loop: Optional[GLib.MainLoop] = None,
    ):
        # install local copy of beamformer plugin
        # to be replaced by a download from an official release location
        source = os.path.join(os.path.dirname(__file__), "../../libs/libgstimx_beamformer.so")
        target = "/usr/lib/gstreamer-1.0/libgstimx_beamformer.so"
        os.system(f"cp {source} {target}")
        os.system("sync")

        super().__init__(capture_config, playback_config, start_glib_loop, external_glib_loop)

        if "micfil" not in self.capture_device:
            logger.warning(
                f"This audiomanager gstreamer pipeline has been tested with micfilaudio, not {self.capture_device}. "
                "Check that number of microphones and audio properties are compatible"
            )

    # =========================================================================
    # Capture implementation
    # =========================================================================

    def _create_capture_pipeline(self) -> Gst.Pipeline:
        """
        Create GStreamer capture pipeline with resampling.

        Pipeline structure:
        alsasrc -> caps filter -> audioconvert -> audioresample -> caps filter -> appsink

        - alsasrc: Captures audio from ALSA device
        - caps filter: Enforces input format constraints
        - audioconvert: Converts between different audio formats
        - audioresample: Resamples to target sample rate with high quality
        - caps filter: Enforces output format for processing
        - appsink: Provides audio data to application via callbacks

        Returns:
            Configured GStreamer pipeline ready to start
        """
        blocksize = self.capture_config.blocksize_bytes

        # Capture Pipeline
        # microphone selection and coordinates correspond to the 8MIC-RPI-MX8 microphone array
        pipeline_str = (
            f"alsasrc device={self.capture_device} blocksize={blocksize} ! "
            f"queue name=queue_bf max-size-buffers=10 leaky=downstream ! "
            f"audio/x-raw,channels=4,rate={self.capture_config.sample_rate},format=S32LE,layout=interleaved ! "
            f"audioconvert ! "
            f"audio/x-raw,channels=4,rate=16000,format=F32LE,layout=interleaved ! "
            f"imx_beamformer name=bf mic-coordinates=\"<<0.0, 0.0, 0.0>, "
            f"<-35.5, 0, 0.0>, <-53.25, -30.75, 0.0>, <-53.25, 30.75, 0.0>>\" ! "
            f"audioconvert ! audioamplify amplification=15 ! rglimiter ! audioconvert ! "
            f"audioconvert ! "
            f"audio/x-raw,format={self.capture_config.format}, "
            f"rate={self.capture_config.sample_rate}, "
            f"channels={self.capture_config.channels}, "
            f"layout=interleaved ! "
            f"audiobuffersplit output-buffer-duration=1/10 ! "
            f"queue name=queue_appsink max-size-buffers=10 leaky=downstream ! "
            f"appsink name=appsink emit-signals=true sync=false max-buffers=1 drop=true "
        )

        logger.debug(f"Capture pipeline: {pipeline_str}")
        pipeline = Gst.parse_launch(pipeline_str)

        # Get appsink element and connect callback for new samples
        appsink = pipeline.get_by_name("appsink")
        appsink.connect("new-sample", self._on_new_sample)
        self.capture_appsink = appsink

        self.bf = pipeline.get_by_name("bf")

        return pipeline

    # Freeze the beamformer during playback to avoid it steering in the playback direction as there is no AEC here.

    def _on_playback_start(self):
        self.bf.set_property("freeze", True)
        return

    def _on_playback_end(self):
        self.bf.set_property("freeze", False)
        return
