# Copyright 2026 NXP
# NXP Confidential and Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

import os
import pickle
import logging

logger = logging.getLogger(__name__)


class SafeUnpickler(pickle.Unpickler):
    def load(self):
        pkl_database = super().load()

        if not isinstance(pkl_database, dict):
            error_text = "Invalid pickle format: Expected a dictionary"
            logger.error(error_text)
            raise ValueError(error_text)

        return pkl_database


class Database:
    """
    Safely loads and validates a RAG database (either from a dict or a pickle file).

    Supports:
    - Loading directly from an in-memory dict.
    - Loading from a path to a pickle (.pkl) file.

    Ensures the database structure follows the expected schema before returning it.
    """

    _ALLOWED_OPTIONAL_KEYS = {
        "database_description",
        "database_generator_files",
        "embedding_model",
    }

    def __init__(self, source: str | dict):
        """
        :param source (str | dict): Either a path to a pickle file or an in-memory database dict.
        :return: serialized database with the correct format
        """
        self.source = source
        self.last_key = -1

    def load(self) -> dict:
        """Load and validate the database from the provided source."""
        if isinstance(self.source, dict):
            logger.debug("Validating in-memory database dictionary.")
            valid_data, self.last_key = self._validate(self.source)
            return valid_data

        elif isinstance(self.source, str):
            if not os.path.isfile(self.source):
                raise FileNotFoundError(f"Database file not found: {self.source}")
            logger.debug(f"Loading and validating database from file: {self.source}")
            with open(self.source, "rb") as file:
                valid_data, self.last_key = self._validate(SafeUnpickler(file).load(), self._ALLOWED_OPTIONAL_KEYS)
                return valid_data

        raise TypeError("Invalid source type:", type(self.source))

    @staticmethod
    def _validate(data: dict, special_allowed_keys=None) -> (dict, int):
        """Ensure the database structure is valid."""
        if not isinstance(data, dict):
            raise ValueError("Invalid database format: expected a dictionary at top level.")

        from torch import Tensor

        if special_allowed_keys is None:
            special_allowed_keys = {}
        last_key_int = -1

        for key, value in data.items():
            if key in special_allowed_keys:
                continue  # Skip optional metadata keys

            if not isinstance(value, dict):
                raise ValueError(f"Invalid entry '{key}': expected dict, got {type(value).__name__}.")

            chunks = value.get("chunks")
            if chunks is None:
                raise ValueError(f"Invalid entry '{key}': missing required key 'chunks'.")
            if not isinstance(chunks, list) or not all(isinstance(item, str) for item in chunks):
                raise ValueError(f"Invalid entry '{key}': 'chunks' must be a list of strings.")

            embeddings = value.get("embeddings")
            if embeddings is None:
                raise ValueError(f"Invalid entry '{key}': missing required key 'embeddings'.")
            if not isinstance(embeddings, Tensor):
                raise ValueError(f"Invalid entry '{key}': 'embeddings' must be a Tensor, is {type(embeddings)}.")

            reranking_embedding = value.get("reranking_embedding")
            if reranking_embedding is None:
                raise ValueError(f"Invalid entry '{key}': missing required key 'reranking_embedding'.")
            if not isinstance(reranking_embedding, Tensor):
                raise ValueError(f"Invalid entry '{key}': 'reranking_embedding' must be a Tensor, is "
                                 f"{type(reranking_embedding)}.")

            try:
                current_key_int = int(key)
                if current_key_int > last_key_int:
                    last_key_int = current_key_int
            except ValueError:
                pass

        logger.debug("Database format validated successfully.")
        return data, last_key_int

    def append(self, items_to_add: dict | list[dict]):
        """
            Validates, waits for file readiness, and merges new data into the database. This method handles both
            single dictionaries and lists of dictionaries. Each dictionary must contain a 'chunks' key
            (list of strings). Example of ``items_to_add`` format:

            {
                "chunks": ["text chunk 1", "text chunk 2"],

                "embeddings": tensor([``len(chunks)``, ``embedding_size``]),

                "reranking_embedding": tensor([``1``, ``embedding_size``]),

                "metadata": "source_document.pdf",

                "...": "..."
            }
            :param items_to_add: A single entry or a list of entries to add.
        """
        items = [items_to_add] if isinstance(items_to_add, dict) else items_to_add

        # Load current state to get correct last_key
        full_db = self.source if isinstance(self.source, dict) else self.load()

        new_entries = {}
        for item in items:
            self.last_key += 1
            new_entries[str(self.last_key)] = item
        self._validate(new_entries)

        full_db.update(new_entries)

        if isinstance(self.source, str):
            tmp_path = f"{self.source}.tmp"
            with open(tmp_path, "wb") as f:
                pickle.dump(full_db, f)
            os.replace(tmp_path, self.source)

        logger.info(f"Successfully appended {len(new_entries)} entries to {self.source}")
        return new_entries
