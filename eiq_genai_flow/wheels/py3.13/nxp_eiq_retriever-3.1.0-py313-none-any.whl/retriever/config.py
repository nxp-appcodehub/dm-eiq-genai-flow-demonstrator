# Copyright 2024-2026 NXP
# NXP Confidential and Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

from dataclasses import dataclass
from retriever.models.embedding_models.embedding_models_manager import DownloadStrategy


@dataclass
class Config:
    # QueryClassifier parameters
    out_of_domain_source_list: tuple[str, ...] = (
        "garbage_model.json",
    )  # Out-of-domain sources to exclude

    # Retrieval inference parameters
    top_k: int = 3  # The number of element pre-selected in the database.
    reranking: bool = True  # Activate the reranking option.
    best_k: int = 1  # The number of element among --top-k added top the prompt (must be <= top_k).
    use_onnx_model: bool = True  # Use the ONNX embedding model instead of torch model.
    use_quant_model: bool = False  # Use the embedding model quantized in QInt8 (only available for ONNX model).

    # Clustering parameters (only used if `use_clusters` set to True)
    cluster_type: str = "centroids"  # Can be "labels" or "centroids"
    num_centroids: int = 8