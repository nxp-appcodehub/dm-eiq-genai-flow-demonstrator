# Copyright 2024-2026 NXP
# NXP Confidential and Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

import os
import time
import torch
import logging
import numpy as np
from typing import Optional
import torch.nn.functional as F
from retriever.database import Database
from retriever.config import Config as RetrievalConfig
from retriever.utils import check_censored_word_presence
from shared_utils.utils import pretty_log
from retriever.models.embedding_models.embedding_models import EmbeddingModel

logger = logging.getLogger(__name__)


class Retriever:
    def __init__(
        self,
        config: RetrievalConfig,
        embedding_model: str | EmbeddingModel,
        rag_db: str | dict,
        use_clusters: bool = False,
    ):

        self.use_onnx_model = config.use_onnx_model
        self.use_quant_model = config.use_quant_model
        self.top_k = config.top_k
        self.best_k = config.best_k
        self.reranking = config.reranking
        self.cluster_type = config.cluster_type if use_clusters else None

        logger.debug("Loading embeddding model")
        if isinstance(embedding_model, str):
            self.embedding_model = EmbeddingModel(name=embedding_model, config=config)
        else:
            self.embedding_model = embedding_model

        self.database = Database(source=rag_db)
        self.chunk_list, self.embedding_list, self.reranking_embedding_list, self.metadata_list = self.load_database()

        if self.cluster_type == "centroids":
            logger.debug("Using K-Means clustering")
            # Pass k_means_clusters_qty only if it is explicitly set
            k_means_args = {"embeddings": self.embedding_list, "k_means_num_centroids": config.num_centroids}
            self.k_means = KMeans(**k_means_args)
        else:
            self.k_means = None

        if self.cluster_type == "labels":
            logger.debug("Using clustering on source attribute")
            # Pass k_means_clusters_qty only if it is explicitly set
            labels = []
            for elem in self.metadata_list:
                source = os.path.splitext(elem.get("source", "None"))[0]
                labels.append(source)
            label_based_clusters_args = {"embeddings": self.embedding_list, "labels": labels}
            self.labeled_clusters = LabelBasedClusters(**label_based_clusters_args)
        else:
            self.labeled_clusters = None

    @staticmethod
    def _split_database(database: dict) -> tuple[list, torch.Tensor, torch.Tensor, list]:
        """
        Split the input dictionary into three aligned components.
        :param database: Input dictionary containing the chunks (text) and their related embeddings and metadata.
        :return: List of chunks, tensor of embeddings, and list of metadata. The elements are aligned.
        """

        embedding_list = []
        reranking_embedding_list = []
        chunk_list = []
        metadata_list = []

        for key, value in database.items():
            num_elements = value["embeddings"].shape[0]
            embeddings = value.pop("embeddings")
            embedding_list.append(embeddings)
            reranking_embedding = value.pop("reranking_embedding")
            reranking_embedding_list.append(reranking_embedding.repeat(num_elements, 1))
            # Store chunks (keeping them as a list since they are likely text)
            chunk_list.extend(value.pop("chunks"))
            # Store metadata (keeping it as a list of dictionaries to avoid tensor conversion issues)
            metadata_list.extend([value.copy() for _ in range(num_elements)])  # Copy to avoid modifying original dict

        return chunk_list, torch.cat(embedding_list), torch.cat(reranking_embedding_list), metadata_list

    def load_database(self):
        database = self.database.load()
        rag_db_info = {}
        embedding_model_version = None

        # Check if the database contains the "embedding_model" key
        if "embedding_model" in database:
            embedding_model_version = database.pop("embedding_model")
            # Verify if the stored embedding model matches the current one
            if embedding_model_version != self.embedding_model.embedding_model_version:
                warning_text = (
                    f"Mismatch in embedding model versions:\n"
                    f"   • Database version = {embedding_model_version},\n"
                    f"   • Inference version = {self.embedding_model.embedding_model_version}\n"
                    f"You can either change the chosen embedding model in config.py or re-generate your database."
                )
                [logger.warning(line) for line in warning_text.split("\n")]
                raise UserWarning(warning_text)
        else:
            logger.warning("Unable to verify if the same embedding model was used during database generation.")

        if "database_description" in database:
            rag_db_info["Description"] = database.pop("database_description")
        if embedding_model_version:
            rag_db_info["Embedding model used for generation"] = embedding_model_version
        if "database_generator_files" in database:
            rag_db_info["Chunk files used for generation"] = database.pop("database_generator_files")
        if rag_db_info:
            pretty_log(name="RAG database information", result_dictionary=rag_db_info)

        return self._split_database(database)

    def append_to_database(self, items_to_add: (dict | list[dict])):
        """
            Validates and appends new entries to the existing RAG database. This method handles both single dictionaries
            and lists of dictionaries. Each dictionary must contain a 'chunks' key (list of strings). Example of
            ``items_to_add`` format:

            {
                "chunks": ["text chunk 1", "text chunk 2"],

                "embeddings": tensor([``len(chunks)``, ``embedding_size``]),

                "reranking_embedding": tensor([``1``, ``embedding_size``]),

                "metadata": "source_document.pdf",

                "...": "..."
            }
            :param items_to_add: A single entry or a list of entries to add.
        """
        valid_items = self.database.append(items_to_add)
        if valid_items:
            chunk_list, embedding_list, reranking_embedding_list, new_metadata_list = self._split_database(valid_items)
            self.chunk_list.extend(chunk_list)
            self.embedding_list = torch.cat([self.embedding_list, embedding_list])
            self.reranking_embedding_list = torch.cat([self.reranking_embedding_list, reranking_embedding_list])
            self.metadata_list.extend(new_metadata_list)
        else:
            logger.warning("Nothing was added to the Database")

    @staticmethod
    def _similarity(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """
        :param x: first input
        :param y: second input
        :return: similarity between the two inputs
        """

        return F.cosine_similarity(x, y, dim=-1)

    @staticmethod
    def _top_k(array: torch.Tensor, k: int) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Get the k highest value(s) and their indexes in the input array.
        :param array: input array in which we look for the highest value(s)
        :param k: number of element to keep
        :return: the index(es) of the highest value(s) in the input array and the corresponding element(s) in the array
        """
        values, indices = torch.topk(array, k, dim=-1)  # Returns values and indices
        return values, indices

    def _find_top_k(
        self, query_embedding: torch.Tensor, cluster_label: str | list[str] = None
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Compute similarity between query embedding and the database embeddings and find the top_k.
        :param query_embedding: embedding of the query
        :return: selected indices in the database and the related similarities
        """

        cluster_embeddings_indexes = None
        # compute similarity between database embeddings and the query
        if self.k_means:
            cluster_embeddings, cluster_embeddings_indexes = self.k_means(embedding=query_embedding)
            sim = self._similarity(cluster_embeddings, query_embedding)
        elif self.labeled_clusters:
            cluster_embeddings, cluster_embeddings_indexes = self.labeled_clusters(cluster_label)
            sim = self._similarity(cluster_embeddings, query_embedding)
        else:
            sim = self._similarity(self.embedding_list, query_embedding)

        # Select top-k similarities
        top_similarity_list, top_index_list = self._top_k(array=sim.flatten(), k=self.top_k)

        if self.cluster_type:
            if cluster_embeddings_indexes is not None:
                top_index_list = cluster_embeddings_indexes[top_index_list.to(dtype=torch.int64)]
            else:
                logger.warning("cluster_type is set but cluster_embeddings_indexes is None.")

        return top_similarity_list, top_index_list

    def _rerank(
        self, top_index_list: torch.Tensor, top_similarity_list: torch.Tensor, query_embedding: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Rerank the order of the relevant chunks by averaging the similarity with the similarity of the question
        part of the chunk (if it exists).
        :param top_index_list: tensor of indices of the most similar chunks
        :param top_similarity_list: tensor of similarities of the most similar chunks
        :param query_embedding: user query embedding
        :return: reranked indexes in the database and the related updated similarities
        """

        # Initialize questions_embeddings tensor
        questions_embeddings = torch.zeros((len(top_index_list), query_embedding.shape[-1]))

        # Extract reranking embeddings from metadata_list
        for i, index in enumerate(top_index_list):
            questions_embeddings[i] = self.reranking_embedding_list[index]

        # Compute similarity using PyTorch's cosine similarity
        new_similarity_list = self._similarity(questions_embeddings, query_embedding)

        # Compute final similarity by averaging
        new_similarity_list = (top_similarity_list + new_similarity_list) / 2

        # Get the reranked indices and similarities
        reranked_similarity_list, new_index_order_list = self._top_k(array=new_similarity_list, k=self.best_k)

        # Reorder top indices accordingly
        # reranked_index_list = [top_index_list[i].item() for i in new_index_order_list]
        reranked_index_list = top_index_list[new_index_order_list]

        return reranked_index_list, reranked_similarity_list

    def __call__(self, query: str, cluster_label: str | list[str] = None) -> tuple[list, list, list]:
        """
        Retrieve the most relevant chunks (and their related metadata) in the database for the input query.
        :param query: user query
        :return: most relevant chunks and related metadata
        """

        start_time = time.time()

        # text query is transformed in an embedding
        query_embedding = self.embedding_model.encode(query)

        # get top_k retrieved embeddings from data and their similarity
        top_similarity_list, top_index_list = self._find_top_k(
            query_embedding=query_embedding, cluster_label=cluster_label
        )

        if self.best_k < self.top_k:
            # reranking
            if self.reranking:
                best_index_list, best_similarity_list = self._rerank(
                    top_index_list, top_similarity_list, query_embedding
                )
            else:
                best_index_list, best_similarity_list = (
                    top_index_list[: self.best_k],
                    top_similarity_list[: self.best_k],
                )

        elif self.best_k == self.top_k:
            best_index_list, best_similarity_list = top_index_list, top_similarity_list

        else:
            error_text = "In config.py, best_k value must be inferior or equal to top_k value."
            logger.error(error_text)
            raise ValueError(error_text)

        # get chunks (texts) and related metadata corresponding to the retrieved embeddings
        best_chunk_list = [self.chunk_list[i] for i in best_index_list]
        best_metadata_list = [self.metadata_list[i] for i in best_index_list]
        best_similarity_list = best_similarity_list.tolist()

        pretty_log(
            name="Retriever",
            result_dictionary={
                "Query": query,
                "Latency": f"{(time.time() - start_time):0.5f}s",
                "Chunks": best_chunk_list,
                "Similarities": best_similarity_list,
                "Metadata": best_metadata_list,
            },
        )

        return best_chunk_list, best_similarity_list, best_metadata_list


class QueryClassifier:
    def __init__(self, config: RetrievalConfig, retriever: Retriever, similarity_threshold: float = 0.65):

        self.retrieval_config = config
        self.retriever = retriever
        self.similarity_threshold = similarity_threshold

    def __call__(self, query: str, cluster_label: str | list[str] = None):
        chunk_list, similarity_list, metadata_list = self.retriever(query=query, cluster_label=cluster_label)

        out_of_domain_qty = sum(
            any(
                ood_source in metadata.get("source", "")
                for ood_source in self.retrieval_config.out_of_domain_source_list
            )
            for metadata in metadata_list
        )  # Garbage model or censored queries detection  # Garbage model or censored queries detection

        if check_censored_word_presence(query):  # Check for censored words in query
            query_category = "CENSORED"

        elif "intent" in metadata_list[0]:  # Assumes intent when first chunk metadata contains intent attribute
            query_category = "INTENT"

        elif out_of_domain_qty > len(chunk_list) // 2:  # Out of domain if the majority of sources are out of domain
            query_category = "REJECTED"

        elif (
            np.mean(similarity_list) < self.similarity_threshold
        ):  # Ambiguous if the similarity average is under threshold
            query_category = "AMBIGUOUS"

        else:  # Default case when no specific conditions are met
            query_category = "ACCEPTED"

        logger.debug(f"QueryClassifier: The query category is: {query_category}")
        return query_category, chunk_list, similarity_list, metadata_list


class KMeans:
    def __init__(self, embeddings: torch.Tensor, k_means_num_centroids: Optional[int] = 8):

        # Importing these only when the class is initialized
        from sklearn.cluster import KMeans
        from sklearn.preprocessing import normalize

        # Assigning imports to instance attributes if needed
        self.KMeans = KMeans
        self.normalize = normalize

        # Number of clusters
        self.k = k_means_num_centroids

        # Normalize embeddings for cosine similarity
        normalized_embeddings = self.normalize(embeddings)

        # Perform K-Means clustering
        kmeans = self.KMeans(n_clusters=self.k, random_state=0)
        kmeans.fit(normalized_embeddings)

        # Store centroids and labels
        self.centroids = torch.tensor(kmeans.cluster_centers_, dtype=torch.float32)
        labels = kmeans.labels_

        # Prepare clusters using PyTorch tensors
        self.clusters = {
            cluster_id: {
                "embedding_list": torch.empty(0, embeddings.shape[1]),
                "index_list": torch.empty(0, dtype=torch.int64),
            }
            for cluster_id in range(self.k)
        }

        for idx, cluster_id in enumerate(labels):
            # Add embeddings to the tensor directly (no need for list append)
            self.clusters[cluster_id]["embedding_list"] = torch.cat(
                (self.clusters[cluster_id]["embedding_list"], embeddings[idx].unsqueeze(0)), dim=0
            )
            self.clusters[cluster_id]["index_list"] = torch.cat(
                (self.clusters[cluster_id]["index_list"], torch.tensor([idx], dtype=torch.int64)), dim=0
            )

    def __call__(self, embedding: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Find the closest cluster and return its embeddings and indices.
        :param embedding: Query tensor of shape (embedding_dim,)
        :return: (Tensor of cluster embeddings, Tensor of corresponding indices)
        """

        # Normalize the input vector
        normalized_embedding = torch.nn.functional.normalize(embedding.view(1, -1), dim=1)

        # Compute distances using PyTorch
        dist_to_centroids = torch.norm(self.centroids - normalized_embedding, dim=1)
        closest_centroid_idx = torch.argmin(dist_to_centroids).item()

        # Retrieve precomputed tensor directly (no conversion needed)
        cluster_embeddings = self.clusters[closest_centroid_idx]["embedding_list"]
        cluster_embeddings_indexes = self.clusters[closest_centroid_idx]["index_list"]

        # Print the K-Means results
        pretty_log(
            name="K-Means",
            result_dictionary={
                "Cluster id": closest_centroid_idx,
                "Similarity with closest centroid": dist_to_centroids[closest_centroid_idx].item(),
                "Cluster size": len(self.clusters[closest_centroid_idx]["embedding_list"]),
            },
        )

        return cluster_embeddings, cluster_embeddings_indexes


class LabelBasedClusters:
    def __init__(self, embeddings: torch.Tensor, labels: list[str]):

        # Ensure the embeddings and labels are of the same length
        if len(embeddings) != len(labels):
            error_text = "Embeddings and labels must have the same length."
            logger.error(error_text)
            raise ValueError(error_text)

        self.embeddings = embeddings

        # Initialize clusters with empty tensors
        self.clusters = {}
        labels_set = set(labels)
        for label in set(labels_set):  # Predefine clusters for unique labels
            self.clusters[label] = {
                "embedding_list": torch.empty((0, embeddings.shape[1]), dtype=embeddings.dtype),
                "index_list": torch.empty((0,), dtype=torch.int64),
            }

        # Populate clusters using torch.cat to avoid list-to-tensor conversion
        for idx, label in enumerate(labels):
            self.clusters[label]["embedding_list"] = torch.cat(
                (self.clusters[label]["embedding_list"], embeddings[idx].unsqueeze(0)), dim=0
            )
            self.clusters[label]["index_list"] = torch.cat(
                (self.clusters[label]["index_list"], torch.tensor([idx], dtype=torch.int64)), dim=0
            )

    def __call__(self, cluster_labels: str | list[str] | None) -> tuple[torch.Tensor, torch.Tensor]:
        if cluster_labels is None:
            cluster_labels = list(self.clusters.keys())

        if isinstance(cluster_labels, str):
            # Convert single text to a list for consistent handling
            cluster_labels = [cluster_labels]

        cluster_embeddings = torch.empty((0, self.embeddings.shape[1]))  # Initialize empty embedding tensor
        cluster_indices = torch.empty((0,), dtype=torch.int)  # Initialize empty index tensor

        for cluster_label in cluster_labels:
            if cluster_label not in self.clusters:
                error_message = f"Cluster label '{cluster_label}' does not exist."
                logger.error(error_message)
                raise KeyError(error_message)

            # Concatenate along dimension 0
            cluster_embeddings = torch.cat((cluster_embeddings, self.clusters[cluster_label]["embedding_list"]), dim=0)
            cluster_indices = torch.cat((cluster_indices, self.clusters[cluster_label]["index_list"]), dim=0)

        # Print the results
        pretty_log(
            name="Label-Based Clusters",
            result_dictionary={
                f"Cluster{'s' if len(cluster_labels) > 1 else ''}": cluster_labels
                if len(cluster_labels) > 1
                else cluster_labels[0],
                f"Cluster{'s' if len(cluster_labels) > 1 else ''} size": len(cluster_embeddings),
            },
        )

        return cluster_embeddings, cluster_indices
