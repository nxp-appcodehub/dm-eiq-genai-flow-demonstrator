# Copyright 2024, 2026 NXP
# NXP Confidential and Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

import os
from .retriever import Retriever, QueryClassifier
from .models.embedding_models.embedding_models import EmbeddingModel
from .config import Config

__all__ = ["Retriever", "QueryClassifier", "EmbeddingModel", "Config"]

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
DEFAULT_DB_PATH = os.path.join(os.path.dirname(__file__), "default_database.pkl")
