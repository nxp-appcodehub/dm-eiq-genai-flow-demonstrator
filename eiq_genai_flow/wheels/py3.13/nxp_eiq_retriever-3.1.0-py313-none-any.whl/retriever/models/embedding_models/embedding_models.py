# Copyright 2025-2026 NXP
# NXP Confidential and Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

import os
import torch
import torch.nn.functional as F
import numpy as np
from transformers import AutoTokenizer, AutoModel
from retriever.config import Config as RetrievalConfig
from shared_utils.utils import get_number_of_cores
from retriever.models.embedding_models.embedding_models_manager import DownloadStrategy, download_tokenizer, download_model
import logging

logger = logging.getLogger(__name__)


class EmbeddingModel:
    name: str = None
    hf_path: str = None
    hf_onnx_model_path: str = ""
    hf_onnx_quantized_model_path: str = ""
    quant_suffix: str = ".Q8"
    hostname: str = "nl2-nxrm.sw.nxp.com"
    search_path: str = "VATEC/eIQ-GenAI-Flow/RAG"
    repository_name: str = "Linux_Factory_v2"

    def __new__(cls, name: str, config: RetrievalConfig, saving_folder: str = None, download_strategy=DownloadStrategy.AUTO):
        """Dynamically instantiate the correct subclass based on `name`."""
        name_to_class_dict = {subclass.name: subclass for subclass in cls.__subclasses__()}
        if name in name_to_class_dict:
            return super().__new__(name_to_class_dict[name])  # Instantiate the correct subclass
        else:
            error_text = f"Unknown model name: {name}"
            logger.error(error_text)
            raise ValueError(error_text)

    def __init__(self, name: str, config: RetrievalConfig, saving_folder: str = None, download_strategy=DownloadStrategy.AUTO):
        """Initialize common attributes for all embedding models."""
        self.name = name
        self.config = config
        self.use_quant = config.use_quant_model
        self.use_onnx = config.use_onnx_model
        self.download_strategy = download_strategy
        if self.use_quant and not self.use_onnx:
            logger.warning("The quantized version of the model is only available using ONNX.")
        self.saving_folder = saving_folder or os.path.dirname(__file__)
        self.use_token_type_ids = getattr(self, "use_token_type_ids", False)
        self.onnx_output_names = getattr(self, "onnx_output_names", ["last_hidden_state"])

        quant_suffix = self.quant_suffix if self.use_quant else ""
        self.onnx_model_path = os.path.join(
            self.saving_folder, self.name, "saved_models", f"{self.name}{quant_suffix}.onnx"
        )
        self.torch_model_path = os.path.join(self.saving_folder, self.name, "saved_models", f"{self.name}.pt")
        self.tokenizer_path = os.path.join(self.saving_folder, self.name, "tokenizer")

        self.embedding_model_version = self.name + (".pt" if not self.use_onnx else (quant_suffix + ".onnx"))
        self.check_existing_model()
        logger.info(f"Embedding model used: {self.embedding_model_version}")

        self._tokenizer = AutoTokenizer.from_pretrained(self.tokenizer_path)
        if self.use_onnx:
            import onnxruntime as ort

            session_options = ort.SessionOptions()
            session_options.intra_op_num_threads = get_number_of_cores()
            self._embedding_model = ort.InferenceSession(
                self.onnx_model_path, providers=["CPUExecutionProvider"], sess_options=session_options
            )
        else:
            self._embedding_model = AutoModel.from_pretrained(self.hf_path)
            state_dict = torch.load(self.torch_model_path, weights_only=True)
            self._embedding_model.load_state_dict(state_dict)


    def check_existing_model(self):
        if not os.path.isdir(self.tokenizer_path) or not os.listdir(self.tokenizer_path):
            download_tokenizer(self)

        if self.use_onnx and not os.path.isfile(self.onnx_model_path):
            download_model(self)

        if not self.use_onnx and not os.path.isfile(self.torch_model_path):
            download_model(self)

    def _encode(self, texts):
        if isinstance(texts, str):
            texts = [texts]

        enc = self._tokenizer(texts, padding=True, truncation=True, return_tensors="pt")
        input_ids = enc["input_ids"]
        attention_mask = enc["attention_mask"]
        token_type_ids = enc.get("token_type_ids", torch.zeros_like(input_ids))

        if self.use_onnx:
            inputs = {"input_ids": input_ids.numpy().astype(np.int64),
                      "attention_mask": attention_mask.numpy().astype(np.int64)}
            if self.use_token_type_ids:
                inputs["token_type_ids"] = token_type_ids.numpy().astype(np.int64)

            model_output = self._embedding_model.run(self.onnx_output_names, inputs)
            output_dict = {
                name: torch.from_numpy(val)
                for name, val in zip(self.onnx_output_names, model_output)
            }

        else:
            model_output = self._embedding_model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                token_type_ids=token_type_ids,
            )
            output_dict = model_output.__dict__

        return {"model_outputs": output_dict,
                "attention_mask": attention_mask,
                "input_ids": input_ids,
                "token_type_ids": token_type_ids}


class AllMiniL6V2(EmbeddingModel):
    name = "all-MiniLM-L6-v2"
    hf_path = "sentence-transformers/all-MiniLM-L6-v2"
    hf_onnx_model_path: str = "onnx/model.onnx"
    hf_onnx_quantized_model_path: str = "onnx/model_qint8_arm64.onnx"
    onnx_output_names: list[str] = ["last_hidden_state"]
    use_token_type_ids: bool = True

    def encode(self, texts):
        output = super()._encode(texts)
        hidden = output["model_outputs"]["last_hidden_state"]
        mask = output["attention_mask"]

        input_mask_expanded = mask.unsqueeze(-1).expand(hidden.size()).float()
        embeddings = torch.sum(hidden * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)
        return F.normalize(embeddings, p=2, dim=1)


class GistAllMiniL6V2(EmbeddingModel):
    name = "GIST-all-MiniLM-L6-v2"
    hf_path = "avsolatorio/GIST-all-MiniLM-L6-v2"
    hf_onnx_model_path = "onnx/model.onnx"
    hf_onnx_quantized_model_path = "onnx/model_quantized.onnx"
    onnx_output_names: list[str] = ["token_embeddings", "sentence_embedding"]
    use_token_type_ids: bool = False

    def encode(self, texts):
        output = super()._encode(texts)
        if "token_embeddings" in output["model_outputs"]:
            hidden = output["model_outputs"]["token_embeddings"]
        else:
            hidden = output["model_outputs"]["last_hidden_state"]
        mask = output["attention_mask"]

        input_mask_expanded = mask.unsqueeze(-1).expand(hidden.size()).float()
        embeddings = torch.sum(hidden * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)
        return F.normalize(embeddings, p=2, dim=1)


class GteSmallZh(EmbeddingModel):
    name = "gte-small-zh"
    hf_path = "thenlper/gte-small-zh"
    onnx_output_names: list[str] = ["last_hidden_state", "pooler_output"]
    use_token_type_ids: bool = True

    def encode(self, texts):
        output = super()._encode(texts)
        hidden = output["model_outputs"]["last_hidden_state"]

        embeddings = hidden[:, 0]
        return F.normalize(embeddings, p=2, dim=1)
