# Copyright 2025-2026 NXP
# NXP Confidential and Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

import os
import torch
import shutil
from enum import Enum
from huggingface_hub import hf_hub_download
from transformers import AutoModel, AutoTokenizer
from shared_utils.utils import download_from_url, search_nexus_download_path
from onnxruntime.quantization import quantize_dynamic, QuantType, quant_pre_process
import warnings
import logging

logger = logging.getLogger(__name__)


class DownloadStrategy(Enum):
    AUTO = "auto"
    HF_ONLY = "hf"
    NEXUS_ONLY = "nexus"
    EXPORT_ONLY = "export"


def download_from_nexus(search_path: str, output_path: str, model_config) -> bool:
    url_list = search_nexus_download_path(hostname=model_config.hostname,
                                          search_path=search_path,
                                          repository_name=model_config.repository_name,
                                          strict=True)
    if len(url_list) != 1:
        return False
    return download_from_url(url=url_list[0], output_path=output_path)


def download_tokenizer(model_config):
    strategy = model_config.download_strategy
    if os.path.isdir(model_config.tokenizer_path) and os.listdir(model_config.tokenizer_path):
        return

    os.makedirs(model_config.tokenizer_path, exist_ok=True)

    if strategy in (DownloadStrategy.AUTO, DownloadStrategy.HF_ONLY):
        try:
            logger.info("Downloading tokenizer from HF")

            tokenizer = AutoTokenizer.from_pretrained(model_config.hf_path)
            tokenizer.save_pretrained(model_config.tokenizer_path)

            return

        except Exception as e:
            logger.warning(f"HF tokenizer download failed: {e}")

            if strategy == DownloadStrategy.HF_ONLY:
                raise

    if strategy in (DownloadStrategy.AUTO, DownloadStrategy.NEXUS_ONLY):
        url_list = search_nexus_download_path(hostname=model_config.hostname,
                                              search_path=(model_config.tokenizer_path.replace(
                                                  model_config.saving_folder,
                                                  model_config.search_path) + "/"),
                                              repository_name=model_config.repository_name)
        len_url_list = len(url_list)
        if len_url_list > 0:
            i = 0
            while (i < len_url_list and download_from_url(url=url_list[i],
                                                          output_path=os.path.join(
                                                              model_config.tokenizer_path,
                                                              os.path.basename(url_list[i])))):
                i += 1
            if i == len_url_list:
                return

        if strategy == DownloadStrategy.NEXUS_ONLY:
            raise RuntimeError("Unable to download tokenizer from Nexus")

    raise RuntimeError(f"Unable to obtain tokenizer '{model_config.hf_path}'")


def download_model(model_config):
    strategy = model_config.download_strategy
    if model_config.use_onnx and os.path.isfile(model_config.onnx_model_path):
        return

    if not model_config.use_onnx:
        download_torch_model(model_config)
        return

    onnx_path = model_config.onnx_model_path

    if strategy in (DownloadStrategy.AUTO, DownloadStrategy.HF_ONLY):
        if model_config.hf_onnx_model_path or model_config.hf_onnx_quantized_model_path:
            try:
                logger.info("Trying HF ONNX download")

                hf_model_path = (model_config.hf_onnx_quantized_model_path if model_config.use_quant
                                 else model_config.hf_onnx_model_path)

                downloaded = hf_hub_download(repo_id=model_config.hf_path,
                                             filename=os.path.basename(hf_model_path),
                                             subfolder=os.path.dirname(hf_model_path),
                                             repo_type="model",
                                             local_dir=os.path.dirname(onnx_path))
                os.replace(downloaded, onnx_path)

                shutil.rmtree(os.path.join(os.path.dirname(onnx_path), ".cache"))
                shutil.rmtree(os.path.join(os.path.dirname(onnx_path), "onnx"))

                logger.info(f"Downloaded ONNX from HF: {onnx_path}")
                return

            except Exception as e:
                logger.warning(f"HF ONNX download failed: {e}")
                if strategy == DownloadStrategy.HF_ONLY:
                    raise

    if strategy in (DownloadStrategy.AUTO, DownloadStrategy.NEXUS_ONLY):
        success = download_from_nexus(search_path=onnx_path.replace(model_config.saving_folder,
                                                                    model_config.search_path),
                                      output_path=onnx_path,
                                      model_config=model_config)
        if success:
            logger.info(f"Downloaded ONNX from Nexus: {onnx_path}")
            return

        if strategy == DownloadStrategy.NEXUS_ONLY:
            raise RuntimeError(f"Unable to download ONNX model from Nexus: {onnx_path}")

    if strategy in (DownloadStrategy.AUTO, DownloadStrategy.EXPORT_ONLY):
        onnx_path = model_config.onnx_model_path.replace(model_config.quant_suffix, "")
        if not os.path.isfile(onnx_path):
            if not os.path.isfile(model_config.torch_model_path):
                download_torch_model(model_config)
            export_onnx(model_config)

        if model_config.use_quant:
            quantize_onnx(model_config)

        if os.path.isfile(model_config.onnx_model_path):
            return

    raise RuntimeError(f"Unable to obtain model '{model_config.hf_path}'")


def download_torch_model(model_config):
    strategy = model_config.download_strategy
    model_path = model_config.torch_model_path

    if os.path.isfile(model_path):
        return

    os.makedirs(os.path.dirname(model_path), exist_ok=True)

    if strategy in (DownloadStrategy.AUTO, DownloadStrategy.HF_ONLY, DownloadStrategy.EXPORT_ONLY):
        try:
            logger.info("Downloading torch model from HF")
            model = AutoModel.from_pretrained(model_config.hf_path)
            torch.save(model.state_dict(), model_path)
            logger.info(f"Saved torch model: {model_path}")
            return

        except Exception as e:
            logger.warning(f"HF torch download failed: {e}")

            if strategy == DownloadStrategy.HF_ONLY:
                raise

    if strategy in (DownloadStrategy.AUTO, DownloadStrategy.NEXUS_ONLY):
        success = download_from_nexus(search_path=model_path.replace(model_config.saving_folder,
                                                                     model_config.search_path),
                                      output_path=model_path,
                                      model_config=model_config)
        if success:
            return
    raise RuntimeError(f"Unable to obtain torch model '{model_config.hf_path}'")


def export_onnx(model_config, model_cls=None):
    warnings.filterwarnings("ignore")

    onnx_path = model_config.onnx_model_path.replace(model_config.quant_suffix, "")

    if os.path.isfile(onnx_path):
        return

    os.makedirs(os.path.dirname(onnx_path), exist_ok=True)

    logger.info("Exporting ONNX model")

    model = AutoModel.from_pretrained(model_config.hf_path, dtype=torch.float32)

    state_dict = torch.load(model_config.torch_model_path, weights_only=True)
    model.load_state_dict(state_dict)
    model.eval()

    tokenizer = AutoTokenizer.from_pretrained(model_config.hf_path)

    dummy_texts = ["hello world", "embedding models are useful"]

    inputs = tokenizer(dummy_texts, return_tensors="pt", padding=True, truncation=True)

    input_ids = inputs["input_ids"]
    attention_mask = inputs["attention_mask"]
    token_type_ids = inputs.get("token_type_ids", torch.zeros_like(input_ids))

    onnx_inputs = {"input_ids": input_ids, "attention_mask": attention_mask}
    input_names = ["input_ids", "attention_mask"]
    if model_config.use_token_type_ids:
        onnx_inputs["token_type_ids"] = token_type_ids
        input_names.append("token_type_ids")

    dynamic_axes = {"input_ids": {0: "batch", 1: "seq"},
                    "attention_mask": {0: "batch", 1: "seq"},
                    **{name: {0: "batch", 1: "seq"} for name in model_config.onnx_output_names}}
    if "token_type_ids" in onnx_inputs:
        dynamic_axes["token_type_ids"] = {0: "batch", 1: "seq"}

    torch.onnx.export(model,
                      tuple(onnx_inputs.values()),
                      onnx_path,
                      input_names=input_names,
                      output_names=model_config.onnx_output_names,
                      dynamic_axes=dynamic_axes,
                      opset_version=20,
                      do_constant_folding=False,
                      external_data=False)
    logger.info(f"Saved ONNX model: {onnx_path}")


def quantize_onnx(model_config):
    base_model = model_config.onnx_model_path.replace(model_config.quant_suffix, "")
    onnx_infer_model_path = base_model.replace(".onnx", ".infer.onnx")
    quant_model = base_model.replace(".onnx", model_config.quant_suffix + ".onnx")

    if os.path.isfile(quant_model):
        return

    if not os.path.isfile(base_model):
        raise RuntimeError("ONNX model required before quantization")
    logger.info("Quantizing ONNX model")

    quant_pre_process(
        base_model,
        output_model_path=onnx_infer_model_path,
        skip_optimization=False,
        skip_onnx_shape=False,
        skip_symbolic_shape=True,  # True
        auto_merge=False,
        int_max=2 ** 31 - 1,
        guess_output_rank=False,
    )

    weight_type = QuantType.QInt8
    _ = quantize_dynamic(model_input=base_model.replace(".onnx", ".infer.onnx"),
                         model_output=base_model.replace(".onnx", model_config.quant_suffix + ".onnx"),
                         weight_type=weight_type)

    logger.info(f"Saved quantized model: {quant_model}")
    os.remove(onnx_infer_model_path)
