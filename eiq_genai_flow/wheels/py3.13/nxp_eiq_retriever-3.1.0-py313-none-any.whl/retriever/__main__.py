# Copyright 2024-2026 NXP
# NXP Confidential and Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

import typer
from enum import Enum
from retriever import ROOT_DIR, DEFAULT_DB_PATH
from retriever.config import Config as RetrievalConfig
from retriever.retriever import Retriever
from shared_utils.utils import setup_logging, get_leaf_classes
from retriever.models.embedding_models.embedding_models import EmbeddingModel
import logging

logger = logging.getLogger(__name__)


def main():
    app = typer.Typer(
        name="Retriever",
        no_args_is_help=True,
        add_completion=False,
        context_settings={"help_option_names": ["-h", "--help"]},
    )

    LoggingLevel = Enum("LoggingLevel", {level: level for level in logging._nameToLevel.keys()})

    AvailableEmbeddingModels = Enum(
        "AvailableEmbeddingModels", {cls_.name: cls_.name for cls_ in get_leaf_classes(EmbeddingModel)}
    )

    rag_config = RetrievalConfig()

    @app.command()
    def parse_args(
        embedding_model: AvailableEmbeddingModels = typer.Option(
            "all-MiniLM-L6-v2",
            "--embedding-model",
            "-e",
            help="The embedding model used for ingestion and retrieval.",
            show_default=True,
        ),
        rag_db_path: str = typer.Option(
            DEFAULT_DB_PATH,
            "--rag-database",
            "-d",
            help="RAG database path.",
        ),
        use_clusters: bool = typer.Option(
            False,
            "--use-clusters",
            "-c",
            help="Use clustering of the database for faster retrieval. Can be configured in config.py file.",
        ),
        logging_level: LoggingLevel = typer.Option(
            "INFO",
            "--logging-level",
            "-l",
            help="Level of displayed information.",
        ),
        use_traceback: bool = typer.Option(
            False,
            "--use-traceback",
            "-t",
            help="Activate Typer traceback of exceptions and errors.",
        ),
    ):
        """
        Retrieve chunk(s) from RAG database.
        """
        app.pretty_exceptions_enable = use_traceback

        logging_level = logging._nameToLevel[logging_level.value]
        setup_logging(
            level=logging_level, root_path=ROOT_DIR
        )

        embedding_model_name = embedding_model.value
        embedding_model = EmbeddingModel(name=embedding_model_name, config=rag_config)

        retriever = Retriever(
            config=rag_config, embedding_model=embedding_model, use_clusters=use_clusters, rag_db=rag_db_path
        )

        # contextual information is retrieved based on the user query
        while True:
            # Ask the user for a question
            user_input = input("Ask a question (or type 'q' to quit): ")

            # Check if the user pressed only Enter (empty input)
            if user_input == "":
                continue  # Do nothing and continue the loop

            # Check if the user wants to quit
            if user_input == "q":
                logger.warning("Exiting the program.")
                break

            best_chunk_list, _, _ = retriever(query=user_input, cluster_label=None)

    app()


if __name__ == "__main__":
    main()
