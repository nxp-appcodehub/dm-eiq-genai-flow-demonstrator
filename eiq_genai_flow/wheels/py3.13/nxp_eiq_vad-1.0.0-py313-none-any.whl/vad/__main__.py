# Copyright 2026 NXP
# NXP Confidential and Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

import logging
import argparse
import numpy as np
import alsaaudio as aa
from vad.vad import VAD
from pathlib import Path
from vad.utils import load_audio
from vad.user_config import UserConfig
from shared_utils.utils import parent_dir, setup_logging, get_default_playback_device

logger = logging.getLogger(__name__)


def vad_with_file(vad: VAD | None, audio_file: str | Path):
    """
    Applies vad on entire input audio file.
    Outputs speech array + speech audio file if vad is set with save_audio to true.
    """

    audio_input = load_audio(audio_file, sample_rate=vad.sample_rate)
    audio_input = audio_input[UserConfig.audio_channel_index]
    is_speech, chunk, _ = vad(audio_input, streaming=False)
    # No speech detected
    if not is_speech:
        logger.warning('Audio is empty!')
        if vad.save_audio:
            logger.warning('No audio file will be generated.')
        return None

    return chunk


def vad_with_file_streaming(vad: VAD | None, audio_file: str | Path):
    """
    Applies vad on input audio file in streaming mode using 512-sample frames.
    Outputs speech array + speech audio file if vad is set with save_audio to true.
    """
    audio_input = load_audio(audio_file, sample_rate=vad.sample_rate)
    audio_input = audio_input[UserConfig.audio_channel_index]

    # If benchmarking multiple files with same vad instance, you must reset vad state for each function call
    # vad.init_streaming_state()

    processed_chunks = []
    speech_buffer = []

    for start_idx in range(0, audio_input.shape[-1], vad.required_samples):
        end_idx = min(start_idx + vad.required_samples, audio_input.shape[-1])
        chunk = audio_input[start_idx:end_idx]

        if chunk.shape[-1] < vad.required_samples:
            logger.debug(
                f"Incomplete chunk for VAD processing of length {chunk.shape[-1]}. "
                f"VAD needs {vad.required_samples} samples.")
            break

        is_speech, chunk, _ = vad(chunk)

        if is_speech:
            speech_buffer.append(chunk)
        elif speech_buffer:  # speech just ended
            processed_chunks.append(np.concatenate(speech_buffer, axis=-1))
            speech_buffer = []

    # Speech continued till end of stream
    if speech_buffer:
        processed_chunks.append(np.concatenate(speech_buffer, axis=-1))

    if not processed_chunks:
        logger.warning('Audio is empty!')
        if vad.save_audio:
            logger.warning('No audio file will be generated.')
        return None

    # Flush just to close .wav file if save_audio is enabled
    vad.flush()

    return np.concatenate(processed_chunks, axis=-1)


def vad_with_mic(vad: VAD, timeout_s=20):
    """
    Applies vad on microphone input.
    Yields speech chunks in streaming mode. Outputs speech audio file if vad is set with save_audio to true.
    """
    window_size_s = vad.required_samples / vad.sample_rate

    # setup alsa
    capture_device = get_default_playback_device()
    pcm = aa.PCM(
        type=aa.PCM_CAPTURE,
        rate=vad.sample_rate,
        channels=1,
        device=capture_device,
        format=aa.PCM_FORMAT_FLOAT_LE,
        periodsize=vad.required_samples
    )

    speech_buffer = []
    logger.info("Recording from microphone...\n")

    total_frames = int(timeout_s / window_size_s)

    for frame_idx in range(total_frames):
        l, data = pcm.read()
        if l > 0:
            chunk = np.frombuffer(data, dtype=np.float32).copy()
            is_speech, chunk, pre_vad_samples = vad(chunk)
            elapsed_seconds = (frame_idx + 1) * window_size_s
            logger.info(f"time {elapsed_seconds:.2f}s, speech: {is_speech}, pre_vad: {pre_vad_samples}")

            if is_speech:
                speech_buffer.append(chunk)
            elif speech_buffer:  # speech just ended
                yield np.concatenate(speech_buffer, axis=-1)
                speech_buffer = []

    # Speech continued till timeout
    if speech_buffer:
        yield np.concatenate(speech_buffer, axis=-1)

    # Flush just to close .wav file if save_audio is enabled
    vad.flush()

    logger.info('Timeout!')


def parse_args():
    parser = argparse.ArgumentParser(description="Audio processing options")

    logging_levels = list(logging._levelToName.values())

    parser.add_argument(
        '-f', '--file',
        metavar='path/to/the/input_file',
        help="Path to the input audio file. "
             "If omitted, the microphone will be used."
    )
    parser.add_argument(
        '-v', '--verbose',
        type=lambda s: s.upper(),
        choices=logging_levels,
        default='INFO',
        help="Specify the verbose mode."
    )
    args = parser.parse_args()

    # Determine source automatically
    if args.file:
        args.source = 'file'
    else:
        args.source = 'mic'

    return args


def main():
    args = parse_args()
    setup_logging(level=logging._nameToLevel[args.verbose], root_path=parent_dir(__file__, level=3))

    vad = VAD(save_audio=UserConfig.save_audio)

    match args.source:

        case 'mic':
            for _ in vad_with_mic(vad, timeout_s=20):
                pass

        case 'file':
            logger.info(f'Using file: {args.file}\n')
            vad_with_file(vad, audio_file=args.file)


if __name__ == '__main__':
    main()
