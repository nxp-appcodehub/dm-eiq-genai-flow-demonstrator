# Copyright 2024-2026 NXP
# NXP Confidential and Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

import os
import torch
import logging
import numpy as np
import collections
import soundfile as sf

from datetime import datetime
from scipy.signal import resample

logger = logging.getLogger(__name__)


class AudioSaver:
    def __init__(self, saving_folder=None):
        if saving_folder is not None:
            self.saving_folder = saving_folder
        else:
            self.saving_folder = os.path.join(os.getcwd(), 'tests', 'results')

    def setup(self, sample_rate, nchannels=1, sampwidth=2):
        import wave
        os.makedirs(self.saving_folder, exist_ok=True)
        self.wav_file_path = os.path.join(self.saving_folder, f'{get_timestamp()}.wav')
        self.wav_file = wave.open(self.wav_file_path, "wb")
        self.wav_file.setnchannels(nchannels)
        self.wav_file.setsampwidth(sampwidth)
        self.wav_file.setframerate(sample_rate)

    def write(self, audio_data):
        self.wav_file.writeframes(audio_data)

    def end(self):
        self.wav_file.close()
        logger.info(f'Audio saved: {self.wav_file_path}')


def get_timestamp():
    return datetime.now().strftime("%Y-%m-%d_%H-%M-%S_%f")


def consume_buffer(buffer: collections.deque, n: int, dtype=np.float32) -> np.ndarray:
    if n > len(buffer):
        raise ValueError(f"Cannot consume {n} items from deque of length {len(buffer)}")

    return np.fromiter((buffer.popleft() for _ in range(n)), dtype=dtype, count=n)


def resample_audio(audio, original_sample_rate, output_sample_rate):
    # Calculate the number of samples needed for the target sample rate
    num_samples = int(audio.shape[-1] * output_sample_rate / original_sample_rate)
    return resample(audio, num_samples, axis=-1)


def load_audio(audio_file, sample_rate=None, as_torch_tensor=False):
    audio, original_sample_rate = sf.read(audio_file, dtype='float32')
    # soundfile returns shape (samples,) or (samples, channels), transpose if needed
    if audio.ndim == 1:
        audio = audio.reshape(1, -1)  # Make it (1, samples) to match torchaudio format
    else:
        audio = audio.T  # Convert (samples, channels) to (channels, samples)

    if sample_rate is not None and original_sample_rate != sample_rate:
        audio = resample_audio(audio, original_sample_rate=original_sample_rate, output_sample_rate=sample_rate)

    if as_torch_tensor:
        audio = torch.from_numpy(audio)

    return audio
