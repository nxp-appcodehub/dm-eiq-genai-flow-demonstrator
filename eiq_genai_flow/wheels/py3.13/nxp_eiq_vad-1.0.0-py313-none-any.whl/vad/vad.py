# Copyright 2025-2026 NXP
# NXP Confidential and Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

import logging
import numpy as np
from collections import deque
from vad.utils import AudioSaver
from silero_vad import load_silero_vad, utils_vad, get_speech_timestamps

logger = logging.getLogger(__name__)


class VAD:
    def __init__(self,
                 sample_rate=16000,
                 threshold=0.3,
                 min_silence_duration_ms=200,
                 pre_vad_samples=1536,
                 save_audio=False
                 ):
        self.required_samples = 512
        self.threshold = threshold
        self.min_silence_duration_ms = min_silence_duration_ms
        self.pre_vad_samples = pre_vad_samples  # samples kept before start of speech
        self.save_audio = save_audio

        assert self.pre_vad_samples >= 0, "pre_vad_samples must be a positive value"

        self.sample_rate = sample_rate
        self.model = load_silero_vad(onnx=True)
        self.iterator = utils_vad.VADIterator(
            model=self.model,
            threshold=self.threshold,
            min_silence_duration_ms=self.min_silence_duration_ms,
            sampling_rate=self.sample_rate
        )

        # Initialize audio saver
        self.audio_saver = None
        self.audio_saver_initialized = False

        # Initialize streaming state
        self.init_streaming_state()

    def init_streaming_state(self):
        """Initialize and reset the streaming state."""
        max_pre_vad_chunks = (self.pre_vad_samples + self.required_samples - 1) // self.required_samples
        self.iterator.reset_states()
        self._pre_vad_buffer = deque(maxlen=max_pre_vad_chunks)
        self._speech_detected = False
        self._chunk_index = 0

    def _init_audio_saver(self):
        """Initialize the audio saver if save_audio is enabled."""
        if self.save_audio and not self.audio_saver_initialized:
            self.audio_saver = AudioSaver()
            self.audio_saver.setup(sample_rate=self.sample_rate)
            self.audio_saver_initialized = True

    def _write_audio(self, audio_data):
        """Write audio data to file if save_audio is enabled."""
        if not self.save_audio:
            return
        self._init_audio_saver()
        self.audio_saver.write(np.int16(audio_data * 32767).tobytes())

    def _end_saving(self):
        """Finalize and close the audio file."""
        if self.audio_saver_initialized and self.audio_saver is not None:
            self.audio_saver.end()
            self.audio_saver_initialized = False
            self.audio_saver = None

    def iterate(self, audio_input):
        """
        Process single frame for real-time voice activity detection.
        Return speech_timestamps.
        """
        return self.iterator(audio_input)

    def get_speech_timestamps(self, audio_input):
        return get_speech_timestamps(
            audio_input,
            self.model,
            threshold=self.threshold,
            min_silence_duration_ms=self.min_silence_duration_ms,
            sampling_rate=self.sample_rate
        )

    def __call__(self, chunk, streaming=True):
        """
        If streaming, process chunks of 512 samples each.
        If False, process entire audio at once.
        """
        if not streaming:
            logger.debug("Processing entire audio at once (non-streaming mode)")
            speech_timestamps = self.get_speech_timestamps(chunk)

            if not speech_timestamps:
                logger.debug("No speech detected in audio")
                return False, None, None

            start = max(0, speech_timestamps[0]['start'] - self.pre_vad_samples)
            end = speech_timestamps[-1]['end']
            pre_vad_samples = speech_timestamps[0]['start'] - start
            logger.debug(f"Speech STARTED at sample {start} (pre_vad of {pre_vad_samples})")
            logger.debug(f"Speech ENDED at sample {end}")

            output_chunk = chunk[start:end]
            self._write_audio(output_chunk)
            self._end_saving()

            return True, output_chunk, pre_vad_samples

        # Streaming mode
        assert chunk.size == self.required_samples, \
            f"Chunk size {chunk.size} != required {self.required_samples}"

        timestamps = self.iterate(chunk)

        has_start = timestamps and 'start' in timestamps
        has_end = timestamps and 'end' in timestamps

        pre_vad_samples = None
        output_chunk = None

        # Speech started
        if has_start and not self._speech_detected:
            self._speech_detected = True
            start_sample = self._chunk_index * self.required_samples
            pre_vad_samples = len(self._pre_vad_buffer) * self.required_samples
            logger.debug(
                f"Speech STARTED at sample {start_sample - pre_vad_samples} "
                f"({start_sample} with pre_vad of {pre_vad_samples})"
            )
            pre_vad_chunks = list(self._pre_vad_buffer)
            output_chunk = np.concatenate(pre_vad_chunks + [chunk], axis=-1) if pre_vad_chunks else chunk
            self._pre_vad_buffer.clear()
            self._write_audio(output_chunk)

        # Speech on-going
        elif self._speech_detected:
            output_chunk = chunk
            self._write_audio(chunk)

            # Speech ended
            if has_end:
                end_sample = (self._chunk_index + 1) * self.required_samples
                logger.debug(f"Speech ENDED at sample {end_sample}")
                self._speech_detected = False
        else:
            self._pre_vad_buffer.append(chunk)

        self._chunk_index += 1

        return self._speech_detected, output_chunk, pre_vad_samples

    def flush(self):
        """
        Close the audio file if save_audio is enabled. Call when stream ends.
        """
        self._speech_detected = False
        self._end_saving()
