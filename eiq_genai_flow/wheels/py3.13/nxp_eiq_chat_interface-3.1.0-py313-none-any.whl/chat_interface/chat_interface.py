# -*- coding: utf-8 -*-

# Copyright 2025-2026 NXP
# NXP Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

import os
import logging
import threading
import time
import signal
import posix_ipc
from PySide6.QtWidgets import (
    QApplication,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QScrollArea,
    QSizePolicy,
    QGraphicsOpacityEffect,
)
from PySide6.QtGui import QFont, QPixmap, QPainter, QPainterPath, QFontMetrics
from PySide6.QtCore import QTimer, Qt, Signal, QPropertyAnimation, QRectF, QRect

logger = logging.getLogger(__name__)


COLOR_MAP = {
    "white": {
        "RED": "#e15554",
        "GREEN": "#3bb273",
    },
    "black": {
        "RED": "#ff5252",
        "GREEN": "#69f0ae",
    },
}

SYSTEM_MESSAGES = {
    "LISTENING_DEFAULT": "◉ Listening...",
    "LISTENING_GREEN": "◉ Listening...",
    "LISTENING_RED": "◉ Listening...",
    "NO_SPEECH": "   ",
    "DISCONNECTED": "○ Disconnected from eIQ GenAI Flow",
    "CONNECTED": "● Connected to eIQ GenAI Flow!",
    "WAKE_WORD": "◎ Waiting for wake-word...",
    "UNVERIFIED_SPK": "◎ Please retry or speak wake-word",
    "WAITING_SPEECH": "◎ Waiting for speech...",
}


def resource_path(relative_path):
    """
    Get absolute path to resource
    """
    base_path = os.path.dirname(os.path.abspath(__file__))
    resolved = os.path.join(base_path, relative_path)
    logger.debug(f"[RESOURCE] Resolved path: {resolved}")
    return resolved


def is_image_path(payload: str) -> bool:
    """
    Check whether the payload is a valid image file path.
    """
    if not payload:
        return False
    if not os.path.isfile(payload):
        return False

    return payload.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".gif"))


def rounded_image(src: QPixmap, radius: int) -> QPixmap:
    """
    Apply rounded corners to a QPixmap.
    """
    logger.debug("[IMAGE] Applying rounded corners")

    result = QPixmap(src.size())
    result.fill(Qt.GlobalColor.transparent)

    painter = QPainter(result)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)

    path = QPainterPath()
    path.addRoundedRect(QRectF(0, 0, src.width(), src.height()), radius, radius)

    painter.setClipPath(path)
    painter.drawPixmap(0, 0, src)
    painter.end()

    return result


class ChatBubble(QWidget):
    def __init__(self, config, content="", is_user=True):
        super().__init__()
        self.config = config
        self.role = "USER" if is_user else "ASSISTANT"
        self.color = self.config.user_color if is_user else self.config.assistant_color
        logger.info(f"[BUBBLE] Creating {self.role} bubble")

        layout = QHBoxLayout()
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(6)

        avatar_path = resource_path("assets/user.png" if is_user else "assets/cpu.png")

        avatar = QLabel()
        avatar_pix = QPixmap(avatar_path).scaled(
            25, 28, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation
        )

        avatar.setPixmap(avatar_pix)
        avatar.setFixedSize(42, 42)
        avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)

        avatar.setStyleSheet(
            f"""
            background-color: {self.color};
            border: 2px solid {self.color};
            border-radius: 20px;
            """
        )

        self.label = QLabel()
        self.label.setWordWrap(True)

        # Image Bubble
        if is_image_path(content):
            logger.debug("[BUBBLE] Rendering image bubble")

            pix = QPixmap(content)
            MAX_WIDTH = 320
            MAX_HEIGHT = 420

            if pix.width() >= pix.height():
                pix = pix.scaledToWidth(
                    MAX_WIDTH,
                    Qt.TransformationMode.SmoothTransformation
                )
            else:
                pix = pix.scaledToHeight(
                    MAX_HEIGHT,
                    Qt.TransformationMode.SmoothTransformation
                )

            pix = rounded_image(pix, radius=14)

            self.label.setPixmap(pix)
            self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.label.setWordWrap(False)

            self.label.setSizePolicy(
                QSizePolicy.Policy.Fixed,
                QSizePolicy.Policy.Fixed
            )

            self.label.setStyleSheet(
                f"""
                background-color: {self.color};
                border-radius: 18px;
                padding: 4px;
                """
            )

        # Text Bubble
        else:
            logger.debug("[BUBBLE] Rendering text bubble")

            self.label.setFont(QFont("Arial", self.config.font_size))
            self.label.setAlignment(
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
            )
            self.label.setText(content)

            self.label.setStyleSheet(
                f"""
                background-color: {self.color};
                color: black;
                border-radius: 18px;
                padding: 8px;
                """
            )

        self.label.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Preferred
        )

        # Layout positioning
        if is_user:
            layout.addStretch()
            layout.addWidget(self.label)
            layout.addWidget(avatar)
        else:
            layout.addWidget(avatar)
            layout.addWidget(self.label)
            layout.addStretch()

        self.setLayout(layout)

    def update_message(self, new_message: str):
        """
        Update text content of an existing bubble.
        """
        logger.debug("[BUBBLE] Updating bubble content")

        if not is_image_path(new_message):
            self.label.setText(new_message)


class MainUI(QWidget):
    bubble_signal = Signal(str, str, str)
    system_signal = Signal(str, str, str)

    def __init__(self, config):
        super().__init__()
        logger.info("[INIT] Initializing MainUI")
        self.config = config

        self.egf_to_gui_queue = posix_ipc.MessageQueue(
            self.config.egf_to_gui_queue_path,
            flags=posix_ipc.O_CREAT
        )
        self.running = True
        self.connected = False
        self.wwd_detected = False

        # Track active bubbles
        self.current_qst_bubble = None
        self.current_rsp_bubble = None

        # Layout
        main_layout = QVBoxLayout()

        self.chat_container = QWidget()
        self.chat_layout = QVBoxLayout()
        self.chat_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.chat_container.setLayout(self.chat_layout)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setWidget(self.chat_container)
        self.scroll_area.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOn
        )
        self.scroll_area.setFrameShape(QScrollArea.Shape.NoFrame)
        self.scroll_area.setStyleSheet(
            """
            QScrollArea {
                border: none;
                background: transparent;
            }
            QScrollBar:vertical {
                background: transparent;
                width: 12px;
                margin: 0px;
            }
            QScrollBar::handle:vertical {
                background: #CCCCCC;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::add-line:vertical,
            QScrollBar::sub-line:vertical {
                height: 0px;
            }
            QScrollBar::add-page:vertical,
            QScrollBar::sub-page:vertical {
                background: none;
            }
            QScrollBar:horizontal {
                background: transparent;
                height: 12px;
                margin: 0px;
            }
            QScrollBar::handle:horizontal {
                background: #CCCCCC;
                border-radius: 6px;
                min-width: 20px;
            }
            QScrollBar::add-line:horizontal,
            QScrollBar::sub-line:horizontal {
                width: 0px;
            }
            QScrollBar::add-page:horizontal,
            QScrollBar::sub-page:horizontal {
                background: none;
            }
            """
        )

        main_layout.addWidget(self.scroll_area, 2)
        self.setLayout(main_layout)

        # Logo
        bottom_image = QLabel()
        pixmap = QPixmap(resource_path("assets/NXP_Logo.png"))
        pixmap = pixmap.scaledToHeight(
            100, Qt.TransformationMode.SmoothTransformation
        )
        bottom_image.setPixmap(pixmap)
        bottom_image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(bottom_image)

        # Signal Wiring
        self.bubble_signal.connect(self._manage_bubble)
        self.system_signal.connect(self._manage_system_message)

        # Add overlay widget
        self.disconnect_overlay = QLabel(self.scroll_area)
        self.disconnect_overlay.setStyleSheet(
            """
            background-color: rgba(255, 255, 255, 0.7);
            border-radius: 8px;
            """
        )
        self.disconnect_overlay.hide()

        # Initial state message
        self._manage_system_message(
            "create",
            "○ Connecting to eIQ GenAI Flow...",
            ""
        )

        # Track vad / spk status
        self.vad_is_down = None
        self.speaker_verified = False

        # Start listener thread
        self.listener_thread = threading.Thread(
            target=self.queue_listener,
            daemon=True
        )
        self.listener_thread.start()

        # Ctrl+C handling: QTimer gives Python periodic ticks to process signals
        self._signal_timer = QTimer(self)
        self._signal_timer.start(200)
        self._signal_timer.timeout.connect(lambda: None)

        signal.signal(signal.SIGINT, self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)

        logger.info("[INIT] MainUI ready")

    def _handle_signal(self, signum, frame):
        """Handle SIGINT/SIGTERM for graceful shutdown."""
        logger.info(f"[SHUTDOWN] Signal {signum} received")
        self.stop()
        app = QApplication.instance()
        if app:
            app.quit()

    def closeEvent(self, event):
        """Handle window close event."""
        logger.info("[SHUTDOWN] Close event received")
        self.stop()
        super().closeEvent(event)

    # Shutdown
    def stop(self):
        logger.info("[SHUTDOWN] Stopping UI")
        self.running = False
        if hasattr(self, '_signal_timer'):
            self._signal_timer.stop()
        if (self.listener_thread.is_alive() and threading.current_thread() != self.listener_thread):
            self.listener_thread.join(timeout=2)
        logger.info("[SHUTDOWN] UI stopped")

    def resizeEvent(self, event):
        logger.debug("[UI] Resize event triggered")
        super().resizeEvent(event)
        self._update_bubble_widths()

    def _update_bubble_widths(self):
        """
        Dynamically resize bubbles to max 65% of viewport width.
        """
        viewport_width = self.scroll_area.viewport().width()
        if viewport_width <= 0:
            return

        max_width = int(viewport_width * 0.65)

        for i in range(self.chat_layout.count()):
            widget = self.chat_layout.itemAt(i).widget()

            if isinstance(widget, ChatBubble):
                label = widget.label
                text = label.text()

                if not text:
                    continue

                fm = QFontMetrics(label.font())
                rect = fm.boundingRect(
                    QRect(0, 0, max_width, 10000),
                    Qt.TextFlag.TextWordWrap,
                    text
                )

                ideal_width = rect.width() + 24
                label.setMaximumWidth(min(ideal_width, max_width))
                label.setWordWrap(True)

    def _do_smooth_scroll(self):
        """
        Animate scroll to bottom.
        """
        logger.debug("[UI] Smooth scroll")

        # Force layout update before scrolling
        self.chat_container.updateGeometry()
        QApplication.processEvents()

        bar = self.scroll_area.verticalScrollBar()

        if hasattr(self, "_scroll_animation"):
            self._scroll_animation.stop()

        animation = QPropertyAnimation(bar, b"value", self)
        animation.setDuration(250)
        animation.setStartValue(bar.value())
        animation.setEndValue(bar.maximum())
        animation.start()

        self._scroll_animation = animation

    def _clear_system_message(self):
        if self.vad_is_down and not self.speaker_verified:
            self._manage_system_message("update", SYSTEM_MESSAGES["NO_SPEECH"], "")

    def _disconnect_overlay(self):
        logger.debug("Blurring pre-disconnect conversation history")

        for i in range(self.chat_layout.count()):
            widget = self.chat_layout.itemAt(i).widget()
            if isinstance(widget, (ChatBubble, QLabel)):
                opacity_effect = QGraphicsOpacityEffect()
                opacity_effect.setOpacity(0.4)
                widget.setGraphicsEffect(opacity_effect)

    def _manage_system_message(self, action_type: str, message: str = "", color: str = ""):
        logger.info(f"System message received: action_type={action_type}, message={message}, color={color}")
        label = getattr(self, "last_sys_message", None)
        if label is None:
            action_type = "create"

        color_value = COLOR_MAP[self.config.background_color].get(color, self.config.system_font_color)

        if action_type == "create":
            label = QLabel()
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)

            if is_image_path(message):
                logger.debug("[SYSTEM] Rendering image system message")
                pix = QPixmap(message)
                viewport_width = self.scroll_area.viewport().width()
                max_width = int(viewport_width * 0.9)
                max_height = int(viewport_width * 0.6)
                if pix.width() >= pix.height():
                    pix = pix.scaledToWidth(
                        max_width,
                        Qt.TransformationMode.SmoothTransformation
                    )
                else:
                    pix = pix.scaledToHeight(
                        max_height,
                        Qt.TransformationMode.SmoothTransformation
                    )
                label.setPixmap(pix)
                self.last_sys_message = label

            else:
                logger.debug("[SYSTEM] Rendering text system message")
                label = QLabel(message)
                label.setFont(QFont("Arial", self.config.font_size))
                label.setAlignment(Qt.AlignmentFlag.AlignCenter)
                label.setWordWrap(True)
                label.setTextFormat(Qt.TextFormat.RichText)
                label.setStyleSheet(
                    f"""
                    font-style: italic;
                    color: {color_value};
                    background-color: transparent;
                    padding: 6px 0px;
                    margin-top: 8px;
                    margin-bottom: 8px;
                    border: none;
                    """
                )
                self.last_sys_message = label
            self.chat_layout.addWidget(label)

            if message == SYSTEM_MESSAGES["LISTENING_DEFAULT"]:
                self.vad_is_down = False

        elif action_type == "update":
            if label is not None:
                label.setTextFormat(Qt.TextFormat.RichText)
                label.setText(message)
                label.setFont(QFont("Arial", self.config.font_size))
                label.setStyleSheet(
                    f"""
                    color: {color_value};
                    background-color: transparent;
                    font-style: italic;
                    padding: 6px 0px;
                    margin-top: 8px;
                    margin-bottom: 8px;
                    border: none;
                    """
                )
                label.updateGeometry()
                QApplication.processEvents()

            # Handle speech / no speech system message
            if message == SYSTEM_MESSAGES["NO_SPEECH"]:
                self.vad_is_down = True
            if message == SYSTEM_MESSAGES["LISTENING_DEFAULT"]:
                self.vad_is_down = False

            # Timeout for unrecognized speaker
            if self.vad_is_down and not self.speaker_verified:
                QTimer.singleShot(1000, self._clear_system_message)

        elif action_type == "next":
            self.last_sys_message = None

        else:  # action_type == "close"
            if label is not None:
                self.chat_layout.removeWidget(label)
                label.hide()
                label.deleteLater()
                self.last_sys_message = None

        QTimer.singleShot(30, self._do_smooth_scroll)

    def _manage_bubble(self, type, speaker, message):
        logger.info(f"Bubble message received: action_type={type}, speaker={speaker}, message={message}")
        action = type
        if (self.current_qst_bubble is not None and speaker == "User" and type == "create") or (
            self.current_rsp_bubble is not None and speaker == "AI" and type == "create"
        ):
            # Prevent multiple bubbles from being created simultaneously
            action = "update"

        is_user = speaker == "User"

        if action == "create":
            bubble = ChatBubble(config=self.config.bubble_config, content=message, is_user=is_user)
            self.chat_layout.addWidget(bubble)

            if is_user:
                self.current_qst_bubble = bubble
                self.current_rsp_bubble = None
            else:
                self.current_qst_bubble = None
                self.current_rsp_bubble = bubble

        elif action == "update":
            if is_user:
                if self.current_qst_bubble:
                    self.current_qst_bubble.update_message(message)
            else:
                if self.current_rsp_bubble:
                    self.current_rsp_bubble.update_message(message)

        elif type == "next":
            if is_user:
                self.current_qst_bubble = None
            else:
                self.current_rsp_bubble = None

        else:  # action_type == "close"
            if is_user and self.current_qst_bubble:
                self.chat_layout.removeWidget(self.current_qst_bubble)
                self.current_qst_bubble.hide()
                self.current_qst_bubble.deleteLater()
                self.current_qst_bubble = None

            if not is_user and self.current_rsp_bubble:
                self.chat_layout.removeWidget(self.current_rsp_bubble)
                self.current_rsp_bubble.hide()
                self.current_rsp_bubble.deleteLater()
                self.current_rsp_bubble = None

        QTimer.singleShot(0, self._update_bubble_widths)
        QTimer.singleShot(30, self._do_smooth_scroll)

    def queue_listener(self):
        """
        Background thread:
        - Reads POSIX message queue
        - Emits Qt signals
        """
        logger.info("[THREAD] Queue listener started")

        buffer_rsp = []

        while self.running:
            try:
                message, _ = self.egf_to_gui_queue.receive(timeout=1)
                message = message.decode()
                logger.debug(f"[EIQ_TO_GUI_QUEUE] {message}")

                # Connection
                if message.startswith("CON:"):
                    logger.info("[STATE] Connected to backend")
                    self.connected = True
                    self.wwd_detected = False
                    self.system_signal.emit(
                        "update",
                        SYSTEM_MESSAGES["CONNECTED"],
                        "GREEN"
                    )
                    self.system_signal.emit("next", "", "")
                    continue

                if not self.connected:
                    continue

                # VAD speech activity
                if message.startswith("VAD:"):
                    content = message[4:]
                    color = "GREEN" if self.wwd_detected else ""
                    if content == "<SPEECH>":
                        self.system_signal.emit("update", SYSTEM_MESSAGES["LISTENING_DEFAULT"], color)
                    elif content == "<NO_SPEECH>":
                        message = "WAITING_SPEECH" if self.wwd_detected or self.speaker_verified else "WAKE_WORD"
                        self.system_signal.emit("update", SYSTEM_MESSAGES[message], color)
                    elif content == "<SPEECH_AFTER_WAKE>":
                        self.system_signal.emit("update", SYSTEM_MESSAGES["WAITING_SPEECH"], "GREEN")

                # Speaker verification activity
                elif message.startswith("SPK:"):
                    content = message[4:]
                    if content == "<VERIFIED>":
                        self.system_signal.emit("update", SYSTEM_MESSAGES["LISTENING_GREEN"], "GREEN")
                        self.speaker_verified = True
                    elif content == "<UNVERIFIED>":
                        self.system_signal.emit("update", SYSTEM_MESSAGES["UNVERIFIED_SPK"], "RED")
                        self.speaker_verified = False

                # User Message
                elif message.startswith("QST:"):
                    content = message[4:]

                    if content == "<end>":
                        self.bubble_signal.emit("next", "User", "")

                    elif content == "<stop>":
                        self.system_signal.emit("close", "", "")
                        self.bubble_signal.emit("close", "User", "")

                    else:
                        if self.current_qst_bubble is None:
                            self.system_signal.emit("close", "", "")
                            self.bubble_signal.emit(
                                "create", "User", content
                            )
                            time.sleep(0.1)
                        else:
                            self.bubble_signal.emit(
                                "update", "User", content
                            )

                # Assistant Message
                elif message.startswith("RSP:"):
                    content = message[4:]

                    if content == "<end>":
                        self.bubble_signal.emit("next", "AI", "")
                        buffer_rsp.clear()

                    else:
                        buffer_rsp.append(content)
                        full = "".join(buffer_rsp)

                        if self.current_rsp_bubble is None:
                            self.bubble_signal.emit(
                                "create", "AI", full
                            )
                        else:
                            self.bubble_signal.emit(
                                "update", "AI", full
                            )

                elif message.startswith("CMD:"):
                    logger.info("Command message received")
                    command = message[4:]
                    self.system_signal.emit("create", command, "")
                    self.system_signal.emit("next", "", "")

                elif message.startswith("INT:"):
                    logger.info("Intent message received")
                    intent = message[4:]
                    self.system_signal.emit("close", "", "")
                    self.bubble_signal.emit("create", "AI", f"◆ Intent: {intent}")
                    self.bubble_signal.emit("next", "AI", "")

                # WakeWord detection to Gui
                elif message.startswith("WWD:"):
                    logger.info("Wake message received")
                    self.wwd_detected = True
                    if len(message) > 4:
                        color = message[4:]
                        self.system_signal.emit("update", SYSTEM_MESSAGES["LISTENING_DEFAULT"], color)
                    else:
                        self.system_signal.emit("update", SYSTEM_MESSAGES["LISTENING_DEFAULT"], "")

                # Timeout info to Gui
                elif message.startswith("TMO:"):
                    logger.info("Timeout message received")
                    self.wwd_detected = False
                    self.system_signal.emit("update", SYSTEM_MESSAGES["WAKE_WORD"], "")

                # VIT is started info to Gui
                elif message.startswith("VIS:"):
                    logger.info("VIT message received")
                    color = "GREEN" if self.speaker_verified else ""
                    # Not print wake word message if last speaker is verified
                    message = "WAITING_SPEECH" if self.speaker_verified or self.wwd_detected else "WAKE_WORD"
                    self.system_signal.emit("update", SYSTEM_MESSAGES[message], color)

                # TTS has finished info to Gui
                elif message.startswith("THF:"):
                    logger.info("TTS has finished message received")
                    self.wwd_detected = False
                    pass

                # Disconnect
                elif message.startswith("DIS:"):
                    logger.warning("[STATE] Disconnected from backend")
                    QTimer.singleShot(0, self._disconnect_overlay)
                    self.system_signal.emit(
                        "create",
                        SYSTEM_MESSAGES["DISCONNECTED"],
                        "RED"
                    )
                    self.connected = False
                    self.wwd_detected = False
                else:
                    pass

            except posix_ipc.BusyError:
                continue
            except Exception as e:
                logger.exception(f"[ERROR] Queue listener failure: {e}")
                break
