# Copyright 2026 NXP
# NXP Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

import os
import sys
import signal
import argparse
import subprocess
import logging
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
from chat_interface.chat_interface import MainUI
from chat_interface.config import ChatInterfaceConfig


logger = logging.getLogger(__name__)


def handle_sigint(sig, frame):
    logger.info("Ctrl+C detected, shutting down...")
    QApplication.quit()


def kill_processes():
    """Kill existing instances of chat_interface"""
    current_pid = os.getpid()
    try:
        result = subprocess.run(["pgrep", "-f", "chat_interface"], capture_output=True, text=True)
        if result.stdout.strip():
            # Get process pids and avoid to kill current process
            pids = [int(pid) for pid in result.stdout.strip().split('\n') if int(pid) != current_pid]
            for pid in pids:
                try:
                    print(f"Kill chat_interface instance (pid: {pid})")
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                except Exception as e:
                    print(f"Error killing process {pid}: {e}")
    except Exception as e:
        print(f"Error killing processes: {e}")


def get_args():
    parser = argparse.ArgumentParser(description="Launch NXP Chat Interface GUI")
    logging_levels = list(logging._levelToName.values())

    parser.add_argument("-d", "--dark-mode", action="store_true", help="Use dark mode for the GUI")
    parser.add_argument("-k", "--kill", action="store_true", help="Kill chat_interface processes, then exit")
    parser.add_argument(
        '-l', '--log_level', type=str.upper, choices=logging_levels,
        default='DEBUG', help="Verbose log level")
    return parser.parse_args()


def main():
    args = get_args()
    """Main entry point."""
    logging.basicConfig(
        level=args.log_level,
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    # Register signal handler AFTER QApplication is created
    signal.signal(signal.SIGINT, handle_sigint)

    # Allow Python to process signals every 500ms
    # (Qt event loop blocks Python signal handling otherwise)
    timer = QTimer()
    timer.start(500)
    timer.timeout.connect(lambda: None)

    print("Launching chat_interface")
    config = ChatInterfaceConfig(dark_mode=args.dark_mode)
    kill_processes()

    # Exit if kill-only mode
    if args.kill:
        print("chat_interface processes killed.")
        sys.exit(0)

    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    ui = MainUI(config=config)
    ui.setWindowTitle(config.gui_app_name)
    ui.resize(600, 900)
    ui.setStyleSheet(f"background-color: {config.background_color}; color: {config.background_color};")
    ui.show()

    try:
        sys.exit(app.exec())
    finally:
        ui.stop()


if __name__ == "__main__":
    main()
