# Copyright 2025-2026 NXP
# NXP Proprietary.
# This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such
# terms or by downloading, installing, activating and/or otherwise using the
# software, you are agreeing that you have read, and that you agree to comply
# with and are bound by, such license terms. If you do not agree to be bound
# by the applicable license terms, then you may not retain, install, activate
# or otherwise use the software.

from dataclasses import dataclass, field


@dataclass
class ChatBubbleConfig():
    font_size: float = 13
    user_color: str = "#BBF292"
    assistant_color: str = "#C2E5FF"


@dataclass
class ChatInterfaceConfig:
    gui_app_name: str = "NXP® eIQ® GenAI Flow Demonstrator - GUI Example"
    egf_to_gui_queue_path: str = "/egf_to_gui"
    gui_to_egf_queue_path: str = None
    max_message_size: int = 1024  # Max message size in the queue
    max_messages: int = 10  # Max message count in the queue
    verbose: bool = False

    dark_mode: bool = False
    bubble_config: ChatBubbleConfig = field(default_factory=ChatBubbleConfig)
    font_size: int = 12
    system_font_color: str = ""
    background_color: str = ""

    def __post_init__(self):
        # This runs after the object is created
        if not self.system_font_color:
            self.system_font_color = "#252B2C" if not self.dark_mode else "#FDF0EB"
        if not self.background_color:
            self.background_color = "white" if not self.dark_mode else "black"
